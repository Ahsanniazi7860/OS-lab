/* Operating Systems Lab - Task12_Deadlock */
/* Complete standalone solution for the corresponding lab task. */

#include <iostream>
#include <unistd.h>
#include <sys/wait.h>
#include <sys/mman.h>
#include <sys/stat.h>
#include <fcntl.h>
#include <signal.h>
#include <cstring>
#include <cstdlib>
using namespace std;

#include <thread>
#include <mutex>
mutex mutexA;
mutex mutexB;

void thread1Work() {
    lock_guard<mutex> lockA(mutexA);

    cout << "Thread 1 acquired Lock A, waiting for Lock B ...\n";
    sleep(1);

    // Intentionally creates deadlock.
    mutexB.lock();

    cout << "Thread 1 acquired Lock B\n";

    mutexB.unlock();
}

void thread2Work() {
    lock_guard<mutex> lockB(mutexB);

    cout << "Thread 2 acquired Lock B, waiting for Lock A ...\n";
    sleep(1);

    // Intentionally creates deadlock.
    mutexA.lock();

    cout << "Thread 2 acquired Lock A\n";

    mutexA.unlock();
}
void task12() {
    cout << "\n--- Task 12: Simulating Deadlock Conditions ---\n";
    cout << "WARNING: This task intentionally deadlocks.\n";
    cout << "The program will stop here until you terminate it with Ctrl+C.\n\n";

    /*
       To avoid blocking the menu permanently in this combined program,
       we run the demonstration in separate child processes.
    */

    pid_t pid = fork();

    if (pid < 0) {
        perror("fork");
        return;
    }

    if (pid == 0) {
        thread t1(thread1Work);
        thread t2(thread2Work);

        t1.join();
        t2.join();

        _exit(0);
    } else {
        sleep(3);

        cout << "[ Program execution blocked indefinitely in circular wait ]\n";
        cout << "Terminating the deadlock demonstration child process...\n";

        kill(pid, SIGTERM);
        waitpid(pid, nullptr, 0);

        cout << "Deadlock demonstration ended.\n";
    }
}

int main() {
    task12();
    return 0;
}
