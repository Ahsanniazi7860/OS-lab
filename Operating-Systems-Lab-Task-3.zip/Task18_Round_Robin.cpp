/* Operating Systems Lab - Task18_Round_Robin */
/* Complete standalone solution for the corresponding lab task. */

#include <iostream>
#include <vector>
#include <queue>
#include <algorithm>
#include <string>
#include <iomanip>
#include <climits>
using namespace std;

struct Process {
    string pid;
    int arrival;
    int burst;
    int remaining;
    int priority;

    int completion = 0;
    int turnaround = 0;
    int waiting = 0;
};


void task18() {
    cout << "\n--- Task 18: Round Robin Scheduling ---\n";

    const int quantum = 2;

    vector<Process> p = {
        {"P1", 0, 5, 5, 0},
        {"P2", 0, 4, 4, 0},
        {"P3", 0, 4, 4, 0}
    };

    queue<int> readyQueue;

    for (int i = 0; i < static_cast<int>(p.size()); ++i)
        readyQueue.push(i);

    int currentTime = 0;
    int completed = 0;

    cout << "Quantum = " << quantum << '\n';
    cout << "Execution: ";

    bool first = true;

    while (completed < static_cast<int>(p.size())) {
        if (readyQueue.empty()) {
            currentTime++;
            continue;
        }

        int index = readyQueue.front();
        readyQueue.pop();

        int slice = min(quantum, p[index].remaining);

        cout << (first ? "" : " -> ")
             << p[index].pid
             << " (" << slice << " ms)";
        first = false;

        p[index].remaining -= slice;
        currentTime += slice;

        if (p[index].remaining > 0) {
            readyQueue.push(index);
        } else {
            p[index].completion = currentTime;
            p[index].turnaround =
                p[index].completion - p[index].arrival;
            p[index].waiting =
                p[index].turnaround - p[index].burst;

            completed++;
        }
    }

    cout << '\n';

    printSchedulingTable(p);
}

int main() {
    task18();
    return 0;
}
