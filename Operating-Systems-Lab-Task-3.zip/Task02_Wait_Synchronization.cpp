/* Operating Systems Lab - Task02_Wait_Synchronization */
/* Complete standalone solution for the corresponding lab task. */

#include <iostream>
#include <unistd.h>
#include <sys/wait.h>
#include <sys/mman.h>
#include <sys/stat.h>
#include <fcntl.h>
#include <signal.h>
#include <cstring>
#include <cstdlib>
using namespace std;


void task2() {
    cout << "\n--- Task 2: Process Synchronization via wait() ---\n";

    pid_t pid = fork();

    if (pid < 0) {
        perror("fork");
        return;
    }

    if (pid == 0) {
        cout << "Child executing task ...\n";
        sleep(2);
        cout << "Child exiting with code 42\n";
        _exit(42);
    } else {
        cout << "Parent waiting for child ...\n";

        int status = 0;
        waitpid(pid, &status, 0);

        if (WIFEXITED(status)) {
            cout << "Parent : Child terminated with exit status "
                 << WEXITSTATUS(status) << '\n';
        }
    }
}

int main() {
    task2();
    return 0;
}
