/* Operating Systems Lab - Task16_SJF */
/* Complete standalone solution for the corresponding lab task. */

#include <iostream>
#include <vector>
#include <queue>
#include <algorithm>
#include <string>
#include <iomanip>
#include <climits>
using namespace std;

struct Process {
    string pid;
    int arrival;
    int burst;
    int remaining;
    int priority;

    int completion = 0;
    int turnaround = 0;
    int waiting = 0;
};


void task16() {
    cout << "\n--- Task 16: Shortest Job First (Non-Preemptive) ---\n";

    vector<Process> p = {
        {"P1", 0, 6, 6, 0},
        {"P2", 0, 8, 8, 0},
        {"P3", 0, 2, 2, 0}
    };

    int currentTime = 0;
    int completed = 0;

    vector<string> order;

    while (completed < static_cast<int>(p.size())) {
        int index = -1;

        for (int i = 0; i < static_cast<int>(p.size()); ++i) {
            if (p[i].completion != 0)
                continue;

            if (p[i].arrival <= currentTime) {
                if (index == -1 ||
                    p[i].burst < p[index].burst) {
                    index = i;
                }
            }
        }

        if (index == -1) {
            currentTime++;
            continue;
        }

        Process& x = p[index];

        x.completion = currentTime + x.burst;
        x.turnaround = x.completion - x.arrival;
        x.waiting = x.turnaround - x.burst;

        currentTime = x.completion;
        completed++;

        order.push_back(x.pid);
    }

    cout << "Execution Order : ";
    for (size_t i = 0; i < order.size(); ++i) {
        cout << order[i];
        if (i + 1 < order.size())
            cout << " -> ";
    }
    cout << '\n';

    printSchedulingTable(p);

    double avgWait = 0;
    for (const auto& x : p)
        avgWait += x.waiting;

    avgWait /= p.size();

    cout << fixed << setprecision(2);
    cout << "Average Waiting Time : " << avgWait << " ms\n";
}

int main() {
    task16();
    return 0;
}
