/* Operating Systems Lab - Task01_Parent_Child */
/* Complete standalone solution for the corresponding lab task. */

#include <iostream>
#include <unistd.h>
#include <sys/wait.h>
#include <sys/mman.h>
#include <sys/stat.h>
#include <fcntl.h>
#include <signal.h>
#include <cstring>
#include <cstdlib>
using namespace std;


void task1() {
    cout << "\n--- Task 1: Parent-Child Process Creation & PID Inspection ---\n";

    pid_t pid = fork();

    if (pid < 0) {
        perror("fork");
        return;
    }

    if (pid == 0) {
        cout << "Child Process : PID = " << getpid()
             << ", Parent PID = " << getppid() << '\n';
        _exit(0);
    } else {
        cout << "Parent Process : PID = " << getpid()
             << ", Created Child PID = " << pid << '\n';
        waitpid(pid, nullptr, 0);
    }
}

int main() {
    task1();
    return 0;
}
