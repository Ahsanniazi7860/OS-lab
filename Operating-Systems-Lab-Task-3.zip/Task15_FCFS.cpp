/* Operating Systems Lab - Task15_FCFS */
/* Complete standalone solution for the corresponding lab task. */

#include <iostream>
#include <vector>
#include <queue>
#include <algorithm>
#include <string>
#include <iomanip>
#include <climits>
using namespace std;

struct Process {
    string pid;
    int arrival;
    int burst;
    int remaining;
    int priority;

    int completion = 0;
    int turnaround = 0;
    int waiting = 0;
};


void task15() {
    cout << "\n--- Task 15: First-Come, First-Served (FCFS) ---\n";

    vector<Process> p = {
        {"P1", 0, 5, 5, 0},
        {"P2", 1, 3, 3, 0},
        {"P3", 2, 8, 8, 0}
    };

    sort(p.begin(), p.end(), [](const Process& a, const Process& b) {
        if (a.arrival != b.arrival)
            return a.arrival < b.arrival;
        return a.pid < b.pid;
    });

    int currentTime = 0;

    for (auto& x : p) {
        if (currentTime < x.arrival)
            currentTime = x.arrival;

        x.completion = currentTime + x.burst;
        x.turnaround = x.completion - x.arrival;
        x.waiting = x.turnaround - x.burst;

        currentTime = x.completion;
    }

    printSchedulingTable(p);

    double avgWait = 0;
    for (const auto& x : p)
        avgWait += x.waiting;

    avgWait /= p.size();

    cout << fixed << setprecision(2);
    cout << "Average Waiting Time : " << avgWait << " ms\n";
}

int main() {
    task15();
    return 0;
}
