/* Operating Systems Lab - Task09_Mutex */
/* Complete standalone solution for the corresponding lab task. */

#include <iostream>
#include <thread>
#include <mutex>
#include <condition_variable>
#include <shared_mutex>
#include <queue>
#include <vector>
#include <functional>
using namespace std;

long long mutexCounter = 0;
mutex mtx;

void safeIncrement() {
    for (int i = 0; i < 100000; ++i) {
        lock_guard<mutex> lock(mtx);
        mutexCounter++;
    }
}
void task9() {
    cout << "\n--- Task 9: Critical Section Protection with Mutex ---\n";

    mutexCounter = 0;

    thread t1(safeIncrement);
    thread t2(safeIncrement);

    t1.join();
    t2.join();

    cout << "Final counter with Mutex : "
         << mutexCounter << '\n';
}

int main() {
    task9();
    return 0;
}
