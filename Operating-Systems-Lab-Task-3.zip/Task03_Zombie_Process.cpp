/* Operating Systems Lab - Task03_Zombie_Process */
/* Complete standalone solution for the corresponding lab task. */

#include <iostream>
#include <unistd.h>
#include <sys/wait.h>
#include <sys/mman.h>
#include <sys/stat.h>
#include <fcntl.h>
#include <signal.h>
#include <cstring>
#include <cstdlib>
using namespace std;


void task3() {
    cout << "\n--- Task 3: Simulating and Detecting Zombie Process ---\n";

    pid_t pid = fork();

    if (pid < 0) {
        perror("fork");
        return;
    }

    if (pid == 0) {
        cout << "Child PID : " << getpid() << " terminating now\n";
        _exit(0);
    } else {
        cout << "Parent sleeping for 10 seconds without wait().\n";
        cout << "During this time, inspect another terminal using: ps -l\n";

        sleep(10);

        waitpid(pid, nullptr, 0);
        cout << "Parent cleaned up child. Exiting.\n";
    }
}

int main() {
    task3();
    return 0;
}
