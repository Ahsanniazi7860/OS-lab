/* Operating Systems Lab - Task11_Reader_Writer */
/* Complete standalone solution for the corresponding lab task. */

#include <iostream>
#include <thread>
#include <mutex>
#include <condition_variable>
#include <shared_mutex>
#include <queue>
#include <vector>
#include <functional>
using namespace std;

int sharedData = 0;
shared_mutex rwLock;

void reader(int id) {
    shared_lock<shared_mutex> lock(rwLock);

    cout << "Reader " << id
         << " read value : " << sharedData << '\n';
}

void writer(int id, int value) {
    unique_lock<shared_mutex> lock(rwLock);

    sharedData = value;

    cout << "Writer " << id
         << " updated value to : " << sharedData << '\n';
}
void task11() {
    cout << "\n--- Task 11: Reader-Writer Problem ---\n";

    sharedData = 0;

    thread w1(writer, 1, 42);
    w1.join();

    thread r1(reader, 1);
    thread r2(reader, 2);

    r1.join();
    r2.join();

    thread w2(writer, 2, 99);
    w2.join();

    thread r3(reader, 3);
    r3.join();
}

int main() {
    task11();
    return 0;
}
