/* Operating Systems Lab - Task20_MLFQ */
/* Complete standalone solution for the corresponding lab task. */

#include <iostream>
#include <vector>
#include <queue>
#include <algorithm>
#include <string>
#include <iomanip>
#include <climits>
using namespace std;

struct MLFQProcess {
    string pid;
    int remaining;
    int originalBurst;
    int level;
};


void task20() {
    cout << "\n--- Task 20: Multilevel Feedback Queue (MLFQ) ---\n";

    queue<MLFQProcess> q1;
    queue<MLFQProcess> q2;
    queue<MLFQProcess> q3;

    /*
       Same basic scenario as the manual:
       P1 needs more CPU time and is demoted.
       P2 finishes quickly.
       Aging can promote a waiting process.
    */
    q1.push({"P1", 7, 7, 1});
    q1.push({"P2", 1, 1, 1});

    int currentTime = 0;

    while (!q1.empty() || !q2.empty() || !q3.empty()) {

        if (!q1.empty()) {
            MLFQProcess p = q1.front();
            q1.pop();

            int runTime = min(2, p.remaining);

            cout << "Time " << currentTime
                 << ": " << p.pid
                 << " enters Q1 (runs "
                 << runTime << " ms)";

            p.remaining -= runTime;
            currentTime += runTime;

            if (p.remaining > 0) {
                p.level = 2;
                q2.push(p);
                cout << " -> Demoted to Q2\n";
            } else {
                cout << " -> Terminated\n";
            }
        }
        else if (!q2.empty()) {
            MLFQProcess p = q2.front();
            q2.pop();

            int runTime = min(4, p.remaining);

            cout << "Time " << currentTime
                 << ": " << p.pid
                 << " from Q2 runs "
                 << runTime << " ms";

            p.remaining -= runTime;
            currentTime += runTime;

            if (p.remaining > 0) {
                p.level = 3;
                q3.push(p);
                cout << " -> Demoted to Q3\n";
            } else {
                cout << " -> Finished\n";
            }
        }
        else if (!q3.empty()) {
            MLFQProcess p = q3.front();
            q3.pop();

            cout << "Time " << currentTime
                 << ": " << p.pid
                 << " from Q3 runs until finished\n";

            currentTime += p.remaining;
            p.remaining = 0;

            cout << p.pid << " -> Finished\n";
        }
    }

    cout << "All jobs completed.\n";
}

int main() {
    task20();
    return 0;
}
