/* Operating Systems Lab - Task13_Anonymous_Pipe */
/* Complete standalone solution for the corresponding lab task. */

#include <iostream>
#include <unistd.h>
#include <sys/wait.h>
#include <sys/mman.h>
#include <sys/stat.h>
#include <fcntl.h>
#include <signal.h>
#include <cstring>
#include <cstdlib>
using namespace std;


void task13() {
    cout << "\n--- Task 13: Unidirectional Anonymous Pipe ---\n";

    int fd[2];

    if (pipe(fd) == -1) {
        perror("pipe");
        return;
    }

    pid_t pid = fork();

    if (pid < 0) {
        perror("fork");
        close(fd[0]);
        close(fd[1]);
        return;
    }

    if (pid == 0) {
        close(fd[1]);

        char buffer[256] = {};

        ssize_t bytesRead = read(fd[0], buffer, sizeof(buffer) - 1);

        if (bytesRead > 0) {
            buffer[bytesRead] = '\0';
            cout << "Child read from pipe : " << buffer << '\n';
        }

        close(fd[0]);
        _exit(0);
    } else {
        close(fd[0]);

        const char* message = "Hello Child from Kernel Pipe";

        write(fd[1], message, strlen(message) + 1);

        close(fd[1]);

        waitpid(pid, nullptr, 0);
    }
}

int main() {
    task13();
    return 0;
}
