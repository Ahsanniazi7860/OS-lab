/* Operating Systems Lab - Task10_Producer_Consumer */
/* Complete standalone solution for the corresponding lab task. */

#include <iostream>
#include <thread>
#include <mutex>
#include <condition_variable>
#include <shared_mutex>
#include <queue>
#include <vector>
#include <functional>
using namespace std;

queue<int> bufferQueue;
const int BUFFER_CAPACITY = 3;
mutex bufferMutex;
condition_variable cvProducer;
condition_variable cvConsumer;

void producer() {
    for (int item = 1; item <= 5; ++item) {
        unique_lock<mutex> lock(bufferMutex);

        cvProducer.wait(lock, [] {
            return bufferQueue.size() < BUFFER_CAPACITY;
        });

        bufferQueue.push(item);
        cout << "Produced : " << item << '\n';

        cvConsumer.notify_one();
    }
}

void consumer() {
    for (int i = 1; i <= 5; ++i) {
        unique_lock<mutex> lock(bufferMutex);

        cvConsumer.wait(lock, [] {
            return !bufferQueue.empty();
        });

        int item = bufferQueue.front();
        bufferQueue.pop();

        cout << "Consumed : " << item << '\n';

        cvProducer.notify_one();
    }
}
void task10() {
    cout << "\n--- Task 10: Producer-Consumer using Condition Variables ---\n";

    while (!bufferQueue.empty()) {
        bufferQueue.pop();
    }

    thread p(producer);
    thread c(consumer);

    p.join();
    c.join();
}

int main() {
    task10();
    return 0;
}
