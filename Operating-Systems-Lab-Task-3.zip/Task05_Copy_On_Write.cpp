/* Operating Systems Lab - Task05_Copy_On_Write */
/* Complete standalone solution for the corresponding lab task. */

#include <iostream>
#include <unistd.h>
#include <sys/wait.h>
#include <sys/mman.h>
#include <sys/stat.h>
#include <fcntl.h>
#include <signal.h>
#include <cstring>
#include <cstdlib>
using namespace std;

int shared_counter = 100;

void task5() {
    cout << "\n--- Task 5: Address Space Decoupling & Copy-On-Write ---\n";

    pid_t pid = fork();

    if (pid < 0) {
        perror("fork");
        return;
    }

    if (pid == 0) {
        shared_counter += 50;
        cout << "Child sees shared_counter = " << shared_counter << '\n';
        _exit(0);
    } else {
        waitpid(pid, nullptr, 0);
        cout << "Parent sees shared_counter = " << shared_counter << '\n';
    }
}

int main() {
    task5();
    return 0;
}
