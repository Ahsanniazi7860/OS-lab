/* Operating Systems Lab - Task17_SRTF */
/* Complete standalone solution for the corresponding lab task. */

#include <iostream>
#include <vector>
#include <queue>
#include <algorithm>
#include <string>
#include <iomanip>
#include <climits>
using namespace std;

struct Process {
    string pid;
    int arrival;
    int burst;
    int remaining;
    int priority;

    int completion = 0;
    int turnaround = 0;
    int waiting = 0;
};


void task17() {
    cout << "\n--- Task 17: Shortest Remaining Time First (SRTF) ---\n";

    vector<Process> p = {
        {"P1", 0, 10, 10, 0},
        {"P2", 1, 4, 4, 0},
        {"P3", 5, 2, 2, 0}
    };

    int currentTime = 0;
    int completed = 0;
    string lastPid = "";

    vector<string> timeline;

    while (completed < static_cast<int>(p.size())) {
        int index = -1;

        for (int i = 0; i < static_cast<int>(p.size()); ++i) {
            if (p[i].remaining <= 0)
                continue;

            if (p[i].arrival <= currentTime) {
                if (index == -1 ||
                    p[i].remaining < p[index].remaining) {
                    index = i;
                }
            }
        }

        if (index == -1) {
            currentTime++;
            continue;
        }

        if (lastPid != p[index].pid) {
            timeline.push_back(
                p[index].pid + " starts at " + to_string(currentTime)
            );
            lastPid = p[index].pid;
        }

        p[index].remaining--;
        currentTime++;

        if (p[index].remaining == 0) {
            p[index].completion = currentTime;
            p[index].turnaround =
                p[index].completion - p[index].arrival;
            p[index].waiting =
                p[index].turnaround - p[index].burst;

            completed++;
        }
    }

    cout << "Execution timeline:\n";
    for (const auto& item : timeline)
        cout << item << '\n';

    printSchedulingTable(p);
}

int main() {
    task17();
    return 0;
}
