/* Operating Systems Lab - Task06_Exec_Process_Replacement */
/* Complete standalone solution for the corresponding lab task. */

#include <iostream>
#include <unistd.h>
#include <sys/wait.h>
#include <sys/mman.h>
#include <sys/stat.h>
#include <fcntl.h>
#include <signal.h>
#include <cstring>
#include <cstdlib>
using namespace std;


void task6() {
    cout << "\n--- Task 6: Address Space Replacement via exec() ---\n";

    pid_t pid = fork();

    if (pid < 0) {
        perror("fork");
        return;
    }

    if (pid == 0) {
        cout << "Child replacing its binary with '/bin/ls'...\n";
        cout.flush();

        char* args[] = {
            const_cast<char*>("ls"),
            const_cast<char*>("-l"),
            nullptr
        };

        execvp(args[0], args);

        // This executes only if execvp fails.
        perror("execvp");
        _exit(1);
    } else {
        waitpid(pid, nullptr, 0);
        cout << "Parent reaped replaced child image\n";
    }
}

int main() {
    task6();
    return 0;
}
