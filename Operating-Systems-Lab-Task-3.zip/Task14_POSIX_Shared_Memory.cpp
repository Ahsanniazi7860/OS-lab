/* Operating Systems Lab - Task14_POSIX_Shared_Memory */
/* Complete standalone solution for the corresponding lab task. */

#include <iostream>
#include <unistd.h>
#include <sys/wait.h>
#include <sys/mman.h>
#include <sys/stat.h>
#include <fcntl.h>
#include <signal.h>
#include <cstring>
#include <cstdlib>
using namespace std;


void task14() {
    cout << "\n--- Task 14: POSIX Shared Memory IPC ---\n";

    const char* SHM_NAME = "/shm_os_lab";
    const size_t SHM_SIZE = 1024;

    // Remove an old object if it exists.
    shm_unlink(SHM_NAME);

    int shm_fd = shm_open(
        SHM_NAME,
        O_CREAT | O_RDWR,
        0666
    );

    if (shm_fd == -1) {
        perror("shm_open");
        return;
    }

    if (ftruncate(shm_fd, SHM_SIZE) == -1) {
        perror("ftruncate");
        close(shm_fd);
        shm_unlink(SHM_NAME);
        return;
    }

    void* ptr = mmap(
        nullptr,
        SHM_SIZE,
        PROT_READ | PROT_WRITE,
        MAP_SHARED,
        shm_fd,
        0
    );

    if (ptr == MAP_FAILED) {
        perror("mmap");
        close(shm_fd);
        shm_unlink(SHM_NAME);
        return;
    }

    strcpy(static_cast<char*>(ptr), "OS Shared Memory Payload");

    pid_t pid = fork();

    if (pid < 0) {
        perror("fork");
    } else if (pid == 0) {
        sleep(1);

        cout << "Child read from SHM : "
             << static_cast<char*>(ptr) << '\n';

        munmap(ptr, SHM_SIZE);
        close(shm_fd);

        _exit(0);
    } else {
        waitpid(pid, nullptr, 0);
    }

    munmap(ptr, SHM_SIZE);
    close(shm_fd);
    shm_unlink(SHM_NAME);
}

int main() {
    task14();
    return 0;
}
