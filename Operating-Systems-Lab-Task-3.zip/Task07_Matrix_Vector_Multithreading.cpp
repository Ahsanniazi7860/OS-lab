/* Operating Systems Lab - Task07_Matrix_Vector_Multithreading */
/* Complete standalone solution for the corresponding lab task. */

#include <iostream>
#include <thread>
#include <mutex>
#include <condition_variable>
#include <shared_mutex>
#include <queue>
#include <vector>
#include <functional>
using namespace std;

void multiplyRow(int row,
                 const vector<vector<int>>& matrix,
                 const vector<int>& vec,
                 vector<int>& result) {
    int sum = 0;

    for (size_t col = 0; col < vec.size(); ++col) {
        sum += matrix[row][col] * vec[col];
    }

    result[row] = sum;
}


void task7() {
    cout << "\n--- Task 7: Multithreaded Matrix-Vector Multiplication ---\n";

    vector<vector<int>> matrix = {
        {1, 2, 3},
        {4, 5, 6},
        {7, 8, 9}
    };

    vector<int> vec = {1, 2, 3};
    vector<int> result(3, 0);

    vector<thread> threads;

    for (int i = 0; i < 3; ++i) {
        threads.emplace_back(multiplyRow,
                             i,
                             cref(matrix),
                             cref(vec),
                             ref(result));
    }

    for (auto& t : threads) {
        t.join();
    }

    cout << "Result Vector : [";
    for (size_t i = 0; i < result.size(); ++i) {
        cout << result[i];
        if (i + 1 < result.size()) cout << ", ";
    }
    cout << "]\n";
}

int main() {
    task7();
    return 0;
}
