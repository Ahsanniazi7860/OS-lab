/* Operating Systems Lab - Task19_Preemptive_Priority */
/* Complete standalone solution for the corresponding lab task. */

#include <iostream>
#include <vector>
#include <queue>
#include <algorithm>
#include <string>
#include <iomanip>
#include <climits>
using namespace std;

struct Process {
    string pid;
    int arrival;
    int burst;
    int remaining;
    int priority;

    int completion = 0;
    int turnaround = 0;
    int waiting = 0;
};


void task19() {
    cout << "\n--- Task 19: Preemptive Priority Scheduling ---\n";

    vector<Process> p = {
        {"P1", 0, 4, 4, 2},
        {"P2", 1, 3, 3, 1},
        {"P3", 2, 2, 2, 3}
    };

    int currentTime = 0;
    int completed = 0;

    while (completed < static_cast<int>(p.size())) {
        int index = -1;

        for (int i = 0; i < static_cast<int>(p.size()); ++i) {
            if (p[i].remaining <= 0)
                continue;

            if (p[i].arrival <= currentTime) {
                if (index == -1 ||
                    p[i].priority < p[index].priority) {
                    index = i;
                }
            }
        }

        if (index == -1) {
            currentTime++;
            continue;
        }

        p[index].remaining--;
        currentTime++;

        if (p[index].remaining == 0) {
            p[index].completion = currentTime;
            p[index].turnaround =
                p[index].completion - p[index].arrival;
            p[index].waiting =
                p[index].turnaround - p[index].burst;

            completed++;
        }
    }

    cout << "PID\tPriority\tBurst\tArrival\tWaiting\n";

    for (const auto& x : p) {
        cout << x.pid << '\t'
             << x.priority << '\t'
             << '\t'
             << x.burst << '\t'
             << x.arrival << '\t'
             << x.waiting << '\n';
    }
}

int main() {
    task19();
    return 0;
}
