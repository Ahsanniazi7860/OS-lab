/* Operating Systems Lab - Task08_Race_Condition */
/* Complete standalone solution for the corresponding lab task. */

#include <iostream>
#include <thread>
#include <mutex>
#include <condition_variable>
#include <shared_mutex>
#include <queue>
#include <vector>
#include <functional>
using namespace std;

long long raceCounter = 0;

void raceIncrement() {
    for (int i = 0; i < 100000; ++i) {
        raceCounter++;
    }
}
void task8() {
    cout << "\n--- Task 8: Demonstrating Race Condition ---\n";

    raceCounter = 0;

    thread t1(raceIncrement);
    thread t2(raceIncrement);

    t1.join();
    t2.join();

    cout << "Expected : 200000 | Actual counter : "
         << raceCounter << '\n';

    cout << "Note: The exact incorrect value is not fixed; "
         << "it depends on thread scheduling.\n";
}

int main() {
    task8();
    return 0;
}
