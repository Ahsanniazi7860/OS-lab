/* Operating Systems Lab - Task04_Orphan_Process */
/* Complete standalone solution for the corresponding lab task. */

#include <iostream>
#include <unistd.h>
#include <sys/wait.h>
#include <sys/mman.h>
#include <sys/stat.h>
#include <fcntl.h>
#include <signal.h>
#include <cstring>
#include <cstdlib>
using namespace std;


void task4() {
    cout << "\n--- Task 4: Orphan Process Re-parenting ---\n";

    pid_t pid = fork();

    if (pid < 0) {
        perror("fork");
        return;
    }

    if (pid == 0) {
        cout << "Initial Parent PID : " << getppid() << '\n';
        sleep(3);
        cout << "After parent dies, new Parent PID : " << getppid() << '\n';
        _exit(0);
    } else {
        cout << "Parent PID : " << getpid() << " exiting immediately\n";
        _exit(0);
    }
}

int main() {
    task4();
    return 0;
}
